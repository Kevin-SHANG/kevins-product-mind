#!/usr/bin/env python3
"""扫描 PRD 交付稿中的过程痕迹、自造编号、英文标识与裸原型引用，只报告命中位置供回读修正，不判定通过。

用法：
    scan_prd_traces.py <文档.md> [--allow-codes G1,AC3,F-A] [--allow-terms device_id] [--unfinished]

命中时退出码为 1，文件无法读取时为 2。命中只是线索：逐条回到正文判断；文档术语表已定义的编号、
真实接口字段和来源已确定的英文名用 --allow-* 放行，V1、P0—P3 默认放行。
“变更记录 / 修订记录 / 版本记录”小节内不报过程痕迹；Mermaid 只扫可见文字（流程图标签、时序图消息与注释、参与者别名、图标题），不扫节点 ID 与 init 配置。
裸原型引用：正文出现“参考原型”“见原型图”一类引用，同一行却没有「页面名」或链接时报告。
--unfinished 另报“占位、待补、TODO”一类未完成标记，默认关闭，避免误报正常的待确认项。
不检查节点数、图数量等布局指标。
"""
from __future__ import annotations

import argparse
import re
import sys
from collections import OrderedDict
from pathlib import Path

TRACE = re.compile(
    r"原方案|旧方案|旧稿|原稿|手写稿|过程稿|前序|对应.{0,4}(?:框|原|旧)"
    r"|根据(?:确认|讨论|用户|您|你)的?(?:结论|反馈|意见|要求)"
    r"|(?:按|应)(?:用户|您|你)的?(?:要求|确认|反馈)"
    r"|(?:本次|此次|这次|本轮|上一?轮|上一?版)(?:修改|调整|改为|新增|删除|重构|确认|精修)"
    r"|为(?:消除|解决|避免|减少).{0,24}(?:问题|弯曲|难读|负担|交叉)"
    r"|全文档采用|改图|精修|自检|已核对|校验通过|收敛为"
)
CODE = re.compile(r"(?<![A-Za-z0-9_])(?:[A-Z]{1,3}\d{1,2}(?:-[A-Z0-9]{1,2})?|[A-Z]-[A-Z0-9]{1,2})(?![A-Za-z0-9_])")
CODE_STRONG = re.compile(
    r"(?:子流程|子图|流程|模块|框|调用|返回|进入|跳转|见)\s*【?\s*(" + CODE.pattern + r")"
    r"|【\s*(" + CODE.pattern + r")\s*】"
)
EN = re.compile(
    r"(?<![A-Za-z0-9_])(?:[A-Z][A-Z0-9]*_[A-Z0-9_]*[A-Z0-9]|[a-z][a-z0-9]*_[a-z0-9_]*[a-z0-9]"
    r"|[a-z]+[A-Z][A-Za-z0-9]*)(?![A-Za-z0-9_])"
)
DEFAULT_ALLOW_CODE = re.compile(r"V\d+|P[0-3]")
CHANGELOG = re.compile(r"变更记录|修订记录|版本记录")
PROTO_REF = re.compile(r"(?:参考|参见|参照|详见|见)\s*(?:原型|设计稿|交互稿)(?:图|稿)?")
PROTO_ANCHOR = re.compile(r"「[^」]+」|“[^”]+”|\"[^\"]+\"|https?://|\]\([^)]+\)")
UNFINISHED = re.compile(r"占位|待补|待填|TODO|TBD|FIXME|lorem|placeholder", re.IGNORECASE)
LABEL = re.compile(r'"([^"]*)"|\[([^\]]*)\]|\{([^}]*)\}|\|([^|]*)\||\(([^)]*)\)')


SEQ_TEXT = re.compile(r"^\s*(?:Note\s+(?:over|left of|right of)\s+[^:]+|[^:\[\]{}()|\"]*?(?:-+>>|-+>|-+x|-+\))[^:]*):\s*(.*)$")
SEQ_ALIAS = re.compile(r"^\s*(?:participant|actor)\s+\S+\s+as\s+(.*)$")
TITLE = re.compile(r"^\s*title:?\s+(.*)$")


def mermaid_text(line: str) -> str:
    line = line.split("%%", 1)[0]
    stripped = line.strip()
    for pattern in (SEQ_TEXT, SEQ_ALIAS, TITLE):
        found = pattern.match(line)
        if found:
            return re.sub(r"<[^>]+>", " ", found.group(1))
    if stripped.startswith("subgraph") and not LABEL.search(stripped):
        return stripped[len("subgraph"):]
    parts = ["".join(groups) for groups in LABEL.findall(line)]
    return re.sub(r"<[^>]+>", " ", " ".join(parts))


def iter_lines(text: str):
    """产出 (行号, 位置, 可见文本, 是否在变更记录区)。"""
    fence = None
    headings: list[tuple[int, str]] = []
    for number, raw in enumerate(text.splitlines(), 1):
        stripped = raw.strip()
        if stripped.startswith("```"):
            fence = None if fence is not None else (stripped[3:].strip().lower() or "code")
            continue
        if fence == "mermaid":
            yield number, "图", mermaid_text(raw), False
            continue
        if fence is not None:
            continue
        heading = re.match(r"(#{1,6})\s+(.*)", stripped)
        if heading:
            level = len(heading.group(1))
            headings = [h for h in headings if h[0] < level] + [(level, heading.group(2))]
        in_changelog = any(CHANGELOG.search(h[1]) for h in headings)
        yield number, "标题" if heading else "正文", raw, in_changelog


def scan(text: str, allow_codes: set[str], allow_terms: set[str], unfinished: bool = False) -> list[str]:
    report: list[str] = []
    codes: "OrderedDict[str, list]" = OrderedDict()
    terms: "OrderedDict[str, list]" = OrderedDict()
    for number, where, line, in_changelog in iter_lines(text):
        if not in_changelog:
            for match in TRACE.finditer(line):
                report.append(f"[过程痕迹] L{number} {where}：{match.group(0)} ｜ {line.strip()[:80]}")
        if where == "正文" and not in_changelog:
            found = PROTO_REF.search(line)
            if found and not PROTO_ANCHOR.search(line):
                report.append(f"[裸原型引用] L{number} {where}：{found.group(0)} ｜ {line.strip()[:80]}")
            if unfinished:
                for match in UNFINISHED.finditer(line):
                    report.append(f"[未完成标记] L{number} {where}：{match.group(0)} ｜ {line.strip()[:80]}")
        for match in CODE_STRONG.finditer(line):
            code = match.group(1) or match.group(2)
            if code not in allow_codes:
                report.append(f"[编号指代] L{number} {where}：{match.group(0).strip()} ｜ {line.strip()[:80]}")
        for match in CODE.finditer(line):
            code = match.group(0)
            if code in allow_codes or DEFAULT_ALLOW_CODE.fullmatch(code):
                continue
            codes.setdefault(code, [0, number, where])[0] += 1
        for match in EN.finditer(line):
            term = match.group(0)
            if term not in allow_terms:
                terms.setdefault(term, [0, number, where])[0] += 1
    for title, bucket in (("编号汇总", codes), ("英文标识", terms)):
        if bucket:
            items = "；".join(f"{k}×{v[0]}（首见 L{v[1]} {v[2]}）" for k, v in bucket.items())
            report.append(f"[{title}] {items}")
    return report


def split_list(raw: str | None) -> set[str]:
    return {item.strip() for item in (raw or "").split(",") if item.strip()}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("path", type=Path)
    parser.add_argument("--allow-codes", help="放行的编号，逗号分隔，如文档术语表已定义的 F-A,Q1,AC3")
    parser.add_argument("--allow-terms", help="放行的英文标识，逗号分隔，如真实接口字段")
    parser.add_argument("--unfinished", action="store_true", help="另报占位、待补、TODO 一类未完成标记")
    args = parser.parse_args()
    try:
        text = args.path.read_text(encoding="utf-8")
    except FileNotFoundError:
        print(f"找不到文件：{args.path}", file=sys.stderr)
        return 2
    except UnicodeDecodeError:
        print(f"文件不是 UTF-8 编码：{args.path}", file=sys.stderr)
        return 2
    report = scan(text, split_list(args.allow_codes), split_list(args.allow_terms), args.unfinished)
    print("\n".join(report) if report else "未发现命中项（不代表写作交付检查已通过）")
    return 1 if report else 0


if __name__ == "__main__":
    sys.exit(main())
